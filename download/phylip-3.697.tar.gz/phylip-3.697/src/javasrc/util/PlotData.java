package util;

import java.util.ArrayList;

public class PlotData {
		public int m_plotwidth;
		public int m_plotheight;
		public ArrayList <SectionData> m_treePart;
		public PlotData()
		{
			m_treePart = new ArrayList <SectionData>();
		}
}
