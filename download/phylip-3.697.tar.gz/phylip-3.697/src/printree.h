#include <stdio.h>

#include "phylip.h"

extern void mlk_printree(FILE *fp, tree *t);
extern void mlk_describe(FILE *fp, tree *t, double fracchange);
